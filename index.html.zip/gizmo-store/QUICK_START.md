# 🚀 Quick Start Guide - Gizmo Store Myanmar

## ⚡ 5-Minute Setup

### Step 1: Install Dependencies
```bash
pnpm install
```

### Step 2: Run Development Server
```bash
pnpm dev
```

### Step 3: Open in Browser
Navigate to: **http://localhost:5173**

---

## 📦 Build for Production

```bash
pnpm build
```

Output will be in the `dist/` folder.

---

## 🌐 Deploy to Manus (Easiest)

1. Click **Publish** button in Manus UI
2. Choose custom domain (optional)
3. ✅ Live instantly!

---

## 🌐 Deploy to Vercel (Recommended Alternative)

```bash
npm i -g vercel
vercel
```

Follow the prompts and your site is live!

---

## 🌐 Deploy to Netlify

1. Push code to GitHub
2. Connect repo to Netlify
3. Build command: `pnpm build`
4. Publish directory: `dist`
5. Deploy!

---

## 📝 Key Files to Customize

| File | Purpose |
|------|---------|
| `client/src/pages/Home.tsx` | Main page content & product display |
| `client/src/index.css` | Colors, fonts, design tokens |
| `client/index.html` | Meta tags, title, fonts |
| `package.json` | Project name, version |

---

## 🎨 Quick Customization

### Change Brand Color
Edit `client/src/index.css`:
```css
:root {
  --primary: #B91C1C;  /* Change this */
}
```

### Change Company Name
Edit `client/src/pages/Home.tsx`:
```tsx
<span className="font-bold text-lg">Your Store Name</span>
```

### Update Contact Info
Edit `client/src/pages/Home.tsx` footer section:
```tsx
<a href="tel:+95XXXXXXXXX">Your Phone</a>
```

---

## ✅ Pre-Deployment Checklist

- [ ] Update company name and branding
- [ ] Change contact information
- [ ] Update social media links
- [ ] Test on mobile devices
- [ ] Check dark mode works
- [ ] Verify all links work
- [ ] Test product filtering
- [ ] Check search functionality

---

## 🆘 Common Issues

**Port already in use?**
```bash
pnpm dev -- --port 3000
```

**Build fails?**
```bash
rm -rf node_modules pnpm-lock.yaml
pnpm install
pnpm build
```

**Dark mode not working?**
Clear browser cache and localStorage

---

## 📚 Full Documentation

See `SETUP_GUIDE.md` for complete documentation.

---

**Ready to deploy? Click Publish in Manus UI! 🎉**
