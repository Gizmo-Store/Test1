# Gizmo Store Myanmar - Design Philosophy

## အရွေးချယ်ထားသော Design Approach: **Modern Minimalism with Premium Tech Aesthetic**

### Design Movement
**Contemporary Tech Minimalism** - Clean, sophisticated, and forward-thinking. Inspired by premium tech brands like Apple and Xiaomi that balance simplicity with technical excellence.

### Core Principles
1. **Clarity First** - Every element serves a purpose. No visual clutter, only essential information hierarchy.
2. **Premium Restraint** - Use negative space generously. Quality over quantity in visual elements.
3. **Technical Confidence** - Bold typography, precise spacing, and smooth micro-interactions that convey reliability.
4. **Accessibility by Design** - High contrast, readable fonts, and intuitive navigation for all users.

### Color Philosophy
- **Primary**: Deep Red (#B91C1C) - Conveys energy, trust, and premium quality. Used for CTAs and key actions.
- **Accent**: Warm Gold (#CA8A04) - Subtle luxury touch, used for highlights and premium badges.
- **Neutral Base**: Off-white (#F9FAFB) light mode / Deep Navy (#0C0F14) dark mode - Professional, non-fatiguing backgrounds.
- **Text**: Charcoal (#111827) on light / Off-white (#F1F5F9) on dark - Maximum readability.

**Emotional Intent**: Convey premium quality, trustworthiness, and modern sophistication. The red-gold combination suggests both energy and luxury.

### Layout Paradigm
- **Asymmetric Hero Section** - Large, bold headline with gradient background. Product grid below with generous spacing.
- **Card-Based Product Display** - Minimalist cards with hover elevation effects. Smooth animations on interaction.
- **Sticky Navigation** - Always accessible header with search and theme toggle.
- **Vertical Rhythm** - Consistent spacing system (8px grid) throughout.

### Signature Elements
1. **Gradient Overlays** - Subtle radial gradients in hero section for depth without distraction.
2. **Smooth Hover States** - Cards lift slightly with shadow enhancement on hover. Images zoom subtly.
3. **Micro-interactions** - Toast notifications, smooth transitions, and loading skeletons.

### Interaction Philosophy
- **Responsive Feedback** - Every click/hover provides immediate visual feedback.
- **Smooth Transitions** - 200-300ms easing for all state changes (not instant, not sluggish).
- **Progressive Disclosure** - Modals and details appear on demand, keeping the interface clean.
- **Dark Mode Support** - Full theme switching with localStorage persistence.

### Animation Guidelines
- **Button Interactions**: 160ms ease-out with subtle scale(0.97) on active state.
- **Card Hover**: 250ms cubic-bezier for translateY(-10px) and shadow enhancement.
- **Image Zoom**: 600ms ease for smooth image scaling on hover.
- **Modal Entrance**: 300ms ease-out from scale(0.95) to scale(1).
- **Toast Notifications**: 360ms fade-in/out with 3.2s display duration.
- **Skeleton Loading**: 1.5s pulse animation for loading states.

### Typography System
- **Display Font**: DM Sans Bold (800 weight) - Headlines and logos. Strong, modern, confident.
- **Body Font**: DM Sans Regular (400 weight) - Body text, descriptions. Clean and readable.
- **Secondary Font**: Padauk (Myanmar text) - For Burmese content. Maintains visual harmony.

**Hierarchy**:
- H1: 46px (clamp 28-46px), 800 weight, -1px letter-spacing
- H2: 17px, 800 weight, -0.4px letter-spacing
- Body: 13.5-15px, 400 weight, 1.6-1.7 line-height
- Small: 11-12px, 600 weight, 0.3-0.8px letter-spacing

---

## Key Implementation Notes
- Use Tailwind CSS for all styling with custom design tokens
- Implement React components for modularity and reusability
- Maintain dark mode as a first-class feature
- Ensure mobile-first responsive design
- Optimize for performance with lazy loading and code splitting
