# Gizmo Store Myanmar - Setup & Deployment Guide

## 📋 Project Overview

**Gizmo Store Myanmar** is a professional e-commerce website built with React 19, Tailwind CSS 4, and TypeScript. It features a modern minimalism design with premium tech brand aesthetics, full dark mode support, and responsive mobile-first layout.

**Technology Stack:**
- Frontend: React 19 + TypeScript
- Styling: Tailwind CSS 4 + shadcn/ui components
- Build Tool: Vite 7
- Package Manager: pnpm
- Routing: Wouter (lightweight client-side routing)

---

## 🚀 Local Development Setup

### Prerequisites

Ensure you have the following installed:
- **Node.js** 18+ (recommended: 20 LTS)
- **pnpm** 10+ (install globally: `npm install -g pnpm`)

### Installation Steps

1. **Extract the project** (if using ZIP file):
   ```bash
   unzip gizmo-store-full.zip
   cd gizmo-store
   ```

2. **Install dependencies**:
   ```bash
   pnpm install
   ```

3. **Start development server**:
   ```bash
   pnpm dev
   ```

4. **Open in browser**:
   Navigate to `http://localhost:5173` (or the port shown in terminal)

### Available Scripts

```bash
pnpm dev      # Start development server with hot reload
pnpm build    # Build for production
pnpm preview  # Preview production build locally
pnpm check    # Run TypeScript type checking
pnpm format   # Format code with Prettier
```

---

## 🎨 Design Philosophy

The website follows a **Modern Minimalism with Premium Tech Aesthetic** approach:

- **Color Scheme**: Deep Red (#B91C1C) primary, Warm Gold (#CA8A04) accent
- **Typography**: DM Sans (display/body) + Padauk (Myanmar text)
- **Layout**: Asymmetric hero, card-based product grid, sticky navigation
- **Animations**: Smooth 200-300ms transitions, hover elevation effects
- **Dark Mode**: Full support with localStorage persistence

---

## 📁 Project Structure

```
gizmo-store/
├── client/                 # Frontend application
│   ├── public/            # Static assets (favicon, robots.txt)
│   ├── src/
│   │   ├── pages/         # Page components (Home, NotFound)
│   │   ├── components/    # Reusable UI components
│   │   │   └── ui/        # shadcn/ui components
│   │   ├── contexts/      # React contexts (Theme)
│   │   ├── hooks/         # Custom React hooks
│   │   ├── lib/           # Utility functions
│   │   ├── App.tsx        # Main app component with routing
│   │   ├── main.tsx       # React entry point
│   │   └── index.css      # Global styles & design tokens
│   └── index.html         # HTML template
├── server/                # Backend placeholder (static-only)
├── shared/                # Shared types/constants
├── package.json           # Dependencies
├── vite.config.ts         # Vite configuration
├── tsconfig.json          # TypeScript configuration
└── tailwind.config.ts     # Tailwind CSS configuration
```

---

## 🔧 Configuration

### Environment Variables

Create a `.env` file in the project root if needed:

```env
VITE_API_URL=https://your-api-url.com
VITE_ANALYTICS_ENDPOINT=your-analytics-endpoint
VITE_ANALYTICS_WEBSITE_ID=your-website-id
```

### Tailwind CSS Customization

Edit `client/src/index.css` to modify design tokens:

```css
:root {
  --primary: #B91C1C;      /* Brand red */
  --accent: #CA8A04;       /* Warm gold */
  --background: oklch(...);
  --foreground: oklch(...);
}
```

---

## 📦 Building for Production

### Build the project:

```bash
pnpm build
```

This creates an optimized build in the `dist/` directory.

### Preview production build:

```bash
pnpm preview
```

---

## 🌐 Deployment Options

### Option 1: Manus Hosting (Recommended)

Manus provides built-in hosting with custom domain support:

1. Click the **Publish** button in the Manus UI
2. Configure custom domain (optional)
3. Website is live instantly

**Benefits**: No configuration needed, automatic SSL, built-in analytics, easy rollback.

### Option 2: Vercel

1. Connect your GitHub repository to Vercel
2. Vercel auto-detects Vite configuration
3. Deploy with one click

```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
vercel
```

### Option 3: Netlify

1. Connect GitHub repository to Netlify
2. Configure build settings:
   - **Build command**: `pnpm build`
   - **Publish directory**: `dist`
3. Deploy

### Option 4: Traditional Hosting (VPS/Shared Hosting)

1. Build the project: `pnpm build`
2. Upload `dist/` folder contents to your hosting
3. Configure web server (Nginx/Apache) to serve `index.html` for all routes
4. Enable GZIP compression and caching

**Nginx configuration example**:
```nginx
server {
  listen 80;
  server_name yourdomain.com;
  
  root /var/www/gizmo-store/dist;
  
  location / {
    try_files $uri $uri/ /index.html;
  }
  
  # Enable caching for static assets
  location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$ {
    expires 1y;
    add_header Cache-Control "public, immutable";
  }
}
```

---

## 🔌 API Integration

The website fetches products from Google Sheets via a Google Apps Script endpoint:

```javascript
const URL = 'https://script.google.com/macros/s/AKfycbz659VRQoUdRfXIEg0denAkFZ-0bYjXIUl5Aoq7YFAXuhZXf4j7lr4Z1apDP8Bqckf_/exec';
```

**To modify the data source:**

1. Edit `client/src/pages/Home.tsx`
2. Update the `fetchProducts()` function
3. Ensure the API returns data in this format:

```json
{
  "products": [
    {
      "idx": 0,
      "brand": "Apple",
      "title": "iPhone 15 Pro",
      "price": "₹ 1,299,000",
      "desc": "Premium smartphone",
      "img": "https://image-url.com/phone.jpg"
    }
  ],
  "tracking": [
    {
      "name": "Customer Name",
      "phone": "09xxxxxxxxx",
      "product": "iPhone 15 Pro",
      "date": "2024-05-30",
      "status": "s3"
    }
  ]
}
```

---

## 🎯 Features & Customization

### Adding New Pages

1. Create a new file in `client/src/pages/`:
   ```tsx
   export default function NewPage() {
     return <div>New Page Content</div>;
   }
   ```

2. Add route in `client/src/App.tsx`:
   ```tsx
   <Route path="/new-page" component={NewPage} />
   ```

### Modifying Product Filters

Edit the brand filter logic in `Home.tsx`:
- Change `handleBrandFilter()` to add custom filtering
- Modify the `brands` array to include/exclude categories

### Customizing Colors

Update design tokens in `client/src/index.css`:
- Light mode: `:root {}` section
- Dark mode: `.dark {}` section

### Adding Social Links

Update footer social buttons in `Home.tsx`:
```tsx
<a href="https://facebook.com/your-page" className="...">
  f
</a>
```

---

## 🐛 Troubleshooting

### Port Already in Use

```bash
# Kill process on port 5173 (macOS/Linux)
lsof -ti:5173 | xargs kill -9

# Or use a different port
pnpm dev -- --port 3000
```

### Build Errors

```bash
# Clear cache and reinstall
rm -rf node_modules pnpm-lock.yaml
pnpm install
pnpm build
```

### Dark Mode Not Working

Check localStorage in browser console:
```javascript
localStorage.getItem('gz_dark')  // Should return '0' or '1'
```

### Images Not Loading

Ensure image URLs are accessible and not blocked by CORS. Use absolute URLs or configure CORS headers.

---

## 📊 Performance Optimization

### Already Implemented

- ✅ Code splitting with Vite
- ✅ Lazy image loading
- ✅ CSS minification
- ✅ Tree-shaking unused code
- ✅ Gzip compression ready

### Additional Optimization

1. **Enable image optimization**:
   ```bash
   pnpm add -D vite-plugin-image-optimization
   ```

2. **Add service worker** for offline support:
   ```bash
   pnpm add workbox-window
   ```

3. **Monitor bundle size**:
   ```bash
   pnpm add -D vite-plugin-visualizer
   ```

---

## 🔐 Security Considerations

- ✅ Content Security Policy headers configured
- ✅ XSS protection via React's built-in escaping
- ✅ HTTPS recommended for production
- ✅ Environment variables for sensitive data

**For production deployment:**

1. Set `NODE_ENV=production`
2. Enable HTTPS/SSL certificate
3. Configure security headers (CSP, X-Frame-Options, etc.)
4. Use environment variables for API keys

---

## 📞 Support & Resources

- **React Documentation**: https://react.dev
- **Tailwind CSS**: https://tailwindcss.com
- **Vite**: https://vitejs.dev
- **shadcn/ui**: https://ui.shadcn.com
- **TypeScript**: https://www.typescriptlang.org

---

## 📝 License

This project is created for Gizmo Store Myanmar. All rights reserved.

---

**Last Updated**: May 30, 2024
**Version**: 1.0.0
