import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Loader2, Search, X, Moon, Sun, MessageCircle, ChevronUp } from 'lucide-react';
import { toast } from 'sonner';

/**
 * DESIGN PHILOSOPHY: Modern Minimalism with Premium Tech Aesthetic
 * - Clean, sophisticated interface with premium tech brand inspiration
 * - Bold typography hierarchy with generous whitespace
 * - Smooth micro-interactions and responsive feedback
 * - Full dark mode support with localStorage persistence
 */

interface Product {
  idx: number;
  brand: string;
  title: string;
  price: string;
  desc: string;
  img: string;
}

interface TrackingRecord {
  name: string;
  phone: string;
  product: string;
  date: string;
  status: string;
}

export default function Home() {
  const [products, setProducts] = useState<Product[]>([]);
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedBrand, setSelectedBrand] = useState('all');
  const [displayLimit, setDisplayLimit] = useState(8);
  const [isDark, setIsDark] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [trackingData, setTrackingData] = useState<TrackingRecord[]>([]);
  const [showScrollTop, setShowScrollTop] = useState(false);

  // Initialize dark mode from localStorage
  useEffect(() => {
    const savedDark = localStorage.getItem('gz_dark') === '1';
    setIsDark(savedDark);
    if (savedDark) document.body.classList.add('dark');
  }, []);

  // Fetch products from Google Sheets API
  useEffect(() => {
    fetchProducts();
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleScroll = () => {
    setShowScrollTop(window.scrollY > 300);
  };

  const fetchProducts = async () => {
    const URL = 'https://script.google.com/macros/s/AKfycbz659VRQoUdRfXIEg0denAkFZ-0bYjXIUl5Aoq7YFAXuhZXf4j7lr4Z1apDP8Bqckf_/exec';
    const cache = localStorage.getItem('gz_cache');

    if (cache) {
      try {
        const p = JSON.parse(cache);
        setTrackingData(p.tracking || []);
        setProducts(p.products || []);
        setFilteredProducts(p.products || []);
        setIsLoading(false);
      } catch (e) {
        console.error('Cache parsing error', e);
      }
    }

    try {
      const res = await fetch(URL);
      if (!res.ok) throw new Error(`HTTP Error: ${res.status}`);
      const data = await res.json();
      localStorage.setItem('gz_cache', JSON.stringify(data));
      setTrackingData(data.tracking || []);
      setProducts(data.products || []);
      setFilteredProducts(data.products || []);
      setIsLoading(false);
    } catch (e) {
      console.error('Fetch error', e);
      setIsLoading(false);
      if (!cache) {
        toast.error('Connection failed. Please check your internet and try again.');
      }
    }
  };

  const toggleDarkMode = () => {
    const newDark = !isDark;
    setIsDark(newDark);
    if (newDark) {
      document.body.classList.add('dark');
    } else {
      document.body.classList.remove('dark');
    }
    localStorage.setItem('gz_dark', newDark ? '1' : '0');
  };

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    setDisplayLimit(8);
    applyFilters(query, selectedBrand);
  };

  const handleBrandFilter = (brand: string) => {
    setSelectedBrand(brand);
    setSearchQuery('');
    setDisplayLimit(8);
    applyFilters('', brand);
  };

  const applyFilters = (query: string, brand: string) => {
    let filtered = products;

    if (brand !== 'all') {
      filtered = filtered.filter(p => p.brand.toLowerCase() === brand.toLowerCase());
    }

    if (query) {
      filtered = filtered.filter(p =>
        p.title.toLowerCase().includes(query.toLowerCase()) ||
        p.brand.toLowerCase().includes(query.toLowerCase())
      );
    }

    setFilteredProducts(filtered);
  };

  const brands = ['all', ...Array.from(new Set(products.map(p => p.brand)))];

  return (
    <div className="min-h-screen bg-background text-foreground transition-colors duration-300">
      {/* Header */}
      <header className="sticky top-0 z-50 backdrop-blur-md bg-background/85 border-b border-border">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between gap-4">
          {/* Logo */}
          <div className="flex items-center gap-2 flex-shrink-0">
            <div className="w-9 h-9 bg-gradient-to-br from-red-600 to-red-700 rounded-lg shadow-sm flex items-center justify-center">
              <span className="text-white font-bold text-sm">GZ</span>
            </div>
            <span className="font-bold text-lg text-red-600 hidden sm:inline">Gizmo Store</span>
          </div>

          {/* Search */}
          <div className="flex-1 max-w-sm relative hidden sm:block">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Search products..."
              value={searchQuery}
              onChange={(e) => handleSearch(e.target.value)}
              className="pl-10 pr-8 rounded-full border-border/50 focus:border-red-600"
            />
            {searchQuery && (
              <button
                onClick={() => handleSearch('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Actions */}
          <div className="flex items-center gap-2">
            <button
              onClick={toggleDarkMode}
              className="p-2 hover:bg-muted rounded-lg transition-colors"
              aria-label="Toggle theme"
            >
              {isDark ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </button>
            <button
              onClick={() => toast.info('Message feature coming soon')}
              className="p-2 hover:bg-muted rounded-lg transition-colors"
              aria-label="Message us"
            >
              <MessageCircle className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      {/* Announcement Bar */}
      <div className="bg-red-600 text-white text-xs font-semibold text-center py-2 overflow-hidden">
        <div className="animate-scroll whitespace-nowrap">
          🎉 Authentic Tech Products • Fast Delivery • Trusted Since 2020 • 🎉 Authentic Tech Products • Fast Delivery • Trusted Since 2020
        </div>
      </div>

      {/* Hero Section */}
      <section className="relative overflow-hidden py-16 md:py-24 bg-gradient-to-br from-slate-900 via-slate-800 to-red-900">
        {/* Gradient Overlays */}
        <div className="absolute inset-0 opacity-40">
          <div className="absolute top-0 left-0 w-96 h-96 bg-red-600/30 rounded-full blur-3xl" />
          <div className="absolute bottom-0 right-0 w-96 h-96 bg-amber-600/20 rounded-full blur-3xl" />
        </div>

        <div className="relative z-10 max-w-6xl mx-auto px-4 text-center">
          <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur px-4 py-2 rounded-full mb-6 border border-white/20">
            <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
            <span className="text-white text-xs font-semibold">Premium Tech Store</span>
          </div>

          <h1 className="text-4xl md:text-6xl font-bold text-white mb-4 leading-tight">
            Discover <span className="text-red-400">Premium Tech</span> & Gadgets
          </h1>

          <p className="text-lg text-white/70 max-w-2xl mx-auto mb-8">
            Authentic IT equipment, EDC tools, and premium mobile accessories. Trusted by thousands across Myanmar with nationwide delivery.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              size="lg"
              className="bg-red-600 hover:bg-red-700 text-white rounded-full font-semibold"
              onClick={() => {
                document.querySelector('#products')?.scrollIntoView({ behavior: 'smooth' });
              }}
            >
              Browse Products
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-white/30 text-white hover:bg-white/10 rounded-full font-semibold"
              onClick={() => toast.info('Track order feature available soon')}
            >
              Track Order
            </Button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-4 mt-16 pt-12 border-t border-white/10">
            <div className="text-center">
              <div className="text-2xl md:text-3xl font-bold text-white">5000+</div>
              <div className="text-xs text-white/60 uppercase tracking-wide mt-1">Products</div>
            </div>
            <div className="text-center">
              <div className="text-2xl md:text-3xl font-bold text-white">10K+</div>
              <div className="text-xs text-white/60 uppercase tracking-wide mt-1">Happy Customers</div>
            </div>
            <div className="text-center">
              <div className="text-2xl md:text-3xl font-bold text-white">24/7</div>
              <div className="text-xs text-white/60 uppercase tracking-wide mt-1">Support</div>
            </div>
          </div>
        </div>
      </section>

      {/* Filter Section */}
      <section className="max-w-6xl mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold">Browse by Brand</h2>
          {filteredProducts.length > 0 && (
            <span className="text-sm text-muted-foreground">
              Showing {Math.min(displayLimit, filteredProducts.length)} of {filteredProducts.length}
            </span>
          )}
        </div>

        <div className="flex gap-2 overflow-x-auto pb-2">
          {brands.map(brand => (
            <button
              key={brand}
              onClick={() => handleBrandFilter(brand)}
              className={`px-4 py-2 rounded-full font-semibold whitespace-nowrap transition-all ${
                selectedBrand === brand
                  ? 'bg-red-600 text-white shadow-lg'
                  : 'bg-muted text-foreground hover:bg-muted/80'
              }`}
            >
              {brand === 'all' ? 'All Products' : brand}
            </button>
          ))}
        </div>
      </section>

      {/* Products Section */}
      <section id="products" className="max-w-6xl mx-auto px-4 py-12">
        {isLoading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin text-red-600" />
          </div>
        ) : filteredProducts.length === 0 ? (
          <div className="text-center py-20">
            <div className="text-5xl mb-4">📦</div>
            <h3 className="text-xl font-bold mb-2">No Products Found</h3>
            <p className="text-muted-foreground">Try adjusting your search or filters</p>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {filteredProducts.slice(0, displayLimit).map((product) => (
                <div
                  key={product.idx}
                  className="group bg-card border border-border rounded-lg overflow-hidden hover:shadow-lg transition-all duration-300 hover:translate-y-[-4px]"
                >
                  {/* Product Image */}
                  <div className="aspect-square overflow-hidden bg-muted">
                    <img
                      src={product.img}
                      alt={product.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=300&h=300&fit=crop';
                      }}
                    />
                  </div>

                  {/* Product Info */}
                  <div className="p-3">
                    <div className="text-xs font-bold text-red-600 uppercase tracking-wide mb-1">
                      {product.brand}
                    </div>
                    <h3 className="font-semibold text-sm line-clamp-2 mb-2 text-foreground">
                      {product.title}
                    </h3>
                    <div className="text-lg font-bold text-red-600 mb-3">
                      {product.price}
                    </div>

                    {/* Buttons */}
                    <div className="flex gap-2">
                      <button
                        onClick={() => toast.info(`Details: ${product.title}`)}
                        className="flex-1 px-2 py-1.5 text-xs font-semibold border border-border rounded hover:border-red-600 hover:text-red-600 transition-colors"
                      >
                        Details
                      </button>
                      <button
                        onClick={() => toast.success(`Added to order: ${product.title}`)}
                        className="flex-1 px-2 py-1.5 text-xs font-semibold bg-red-600 text-white rounded hover:bg-red-700 transition-colors"
                      >
                        Buy Now
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Load More Button */}
            {displayLimit < filteredProducts.length && (
              <div className="flex justify-center mt-12">
                <Button
                  onClick={() => setDisplayLimit(prev => prev + 8)}
                  variant="outline"
                  className="rounded-full px-8"
                >
                  Load More Products
                </Button>
              </div>
            )}
          </>
        )}
      </section>

      {/* Footer */}
      <footer className="bg-card border-t border-border mt-20">
        <div className="max-w-6xl mx-auto px-4 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            {/* Brand */}
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-10 h-10 bg-gradient-to-br from-red-600 to-red-700 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold">GZ</span>
                </div>
                <span className="font-bold text-lg">Gizmo Store</span>
              </div>
              <p className="text-sm text-muted-foreground">
                Premium tech and gadgets store based in Mandalay, Myanmar. Authentic products with nationwide delivery.
              </p>
            </div>

            {/* Quick Links */}
            <div>
              <h4 className="font-bold mb-4 text-sm uppercase tracking-wide">Quick Links</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="text-muted-foreground hover:text-foreground transition-colors">About Us</a></li>
                <li><a href="#" className="text-muted-foreground hover:text-foreground transition-colors">Products</a></li>
                <li><a href="#" className="text-muted-foreground hover:text-foreground transition-colors">Contact</a></li>
                <li><a href="#" className="text-muted-foreground hover:text-foreground transition-colors">FAQ</a></li>
              </ul>
            </div>

            {/* Support */}
            <div>
              <h4 className="font-bold mb-4 text-sm uppercase tracking-wide">Support</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="tel:+959957399906" className="text-muted-foreground hover:text-foreground transition-colors">+95 9 957 399 906</a></li>
                <li><a href="https://m.me/100067458529116" className="text-muted-foreground hover:text-foreground transition-colors">Facebook Messenger</a></li>
                <li><a href="https://t.me/Alpakamyanmar" className="text-muted-foreground hover:text-foreground transition-colors">Telegram</a></li>
              </ul>
            </div>

            {/* Social */}
            <div>
              <h4 className="font-bold mb-4 text-sm uppercase tracking-wide">Follow Us</h4>
              <div className="flex gap-2">
                <a href="#" className="w-10 h-10 bg-muted rounded-lg flex items-center justify-center hover:bg-red-600 hover:text-white transition-colors">
                  f
                </a>
                <a href="#" className="w-10 h-10 bg-muted rounded-lg flex items-center justify-center hover:bg-red-600 hover:text-white transition-colors">
                  t
                </a>
                <a href="#" className="w-10 h-10 bg-muted rounded-lg flex items-center justify-center hover:bg-red-600 hover:text-white transition-colors">
                  ig
                </a>
              </div>
            </div>
          </div>

          <div className="border-t border-border pt-8 text-center text-sm text-muted-foreground">
            <p>&copy; 2024 Gizmo Store Myanmar. All rights reserved.</p>
          </div>
        </div>
      </footer>

      {/* Scroll to Top Button */}
      {showScrollTop && (
        <button
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          className="fixed bottom-6 right-6 w-12 h-12 bg-red-600 text-white rounded-full shadow-lg hover:bg-red-700 transition-all flex items-center justify-center animate-in fade-in"
          aria-label="Scroll to top"
        >
          <ChevronUp className="w-6 h-6" />
        </button>
      )}
    </div>
  );
}
